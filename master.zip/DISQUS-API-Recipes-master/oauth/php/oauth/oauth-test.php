<?php

// This should redirect to the second OAuth file provided
echo "<a href='https://disqus.com/api/oauth/2.0/authorize/?client_id=YOUR_PUBLIC_KEY&scope=read,write&response_type=code&redirect_uri=http://www.example.com/oauth-callback.php'>OAuth</a>";

   ?>


