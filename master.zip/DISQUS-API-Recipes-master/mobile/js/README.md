# Disqus Mobile Recipes

## mobiletemplate.html
Example of how you can include Disqus on a single page, for the purpose of embedding in a native app web view. This method uses entirely javascript so it can be hosted on a static cdn, and the required thread parameters are passed in via querystring.