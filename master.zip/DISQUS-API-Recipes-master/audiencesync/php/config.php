<?php
// Disqus Audience Sync config variables

define("DisqusApiPublic", "YOUR_DISQUS_API_PUBLIC_KEY");

define("DisqusApiSecret", "YOUR_DISQUS_API_SECRET_KEY");

define("DisqusShortname", "YOUR_DISQUS_SHORTNAME");

define("BaseSitePath", "http://example.com/callback-directory-folder/");

?>